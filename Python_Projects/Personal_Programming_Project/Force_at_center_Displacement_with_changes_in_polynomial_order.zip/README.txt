Aim:
Displacement analysis with the force applied on the center of the structure 
by changing the polynomial order from 2 to 9

Exact value of Displacement: Displacement at polynomial order 5

Error between the values of the displacements at polynomials 2 to 8 and 
the exact value.


n_ele=150 #number of elements
t_len=8000 #total length (m)
rho=2000  #density of the material (kg/m3)
velocity=2500 #velocity in (m/s)
n=9 #order of polynomials Need to be changed
time_step = 75000 #number of time steps
dom_per=0.4 #dominant period of ricker wavelet source
alpha=0.2 #for defected element K matrix

source_location=int(np.floor(n_global/2)) #Location of the source