Aim:

Damage location prediction by using RMSE error between the damage vector.

Random element number is assigned to be 8 and the location of the damage is calculated by the element length.

n_ele=100 #number of elements
t_len=8000 #total length (m)
rho=2000  #density of the material (kg/m3)
velocity=2500 #velocity in (m/s)
n=2 #order of polynomials
time_step = 7500 #number of time steps
dom_per=0.4 #dominant period of ricker wavelet source
alpha=0.2 #for defected element K matrix

random_ele_number=8 #random number for the defected ele need to be changed

length_of_defected_ele=random_ele_number*e_len #to calculate the length of the randomly generated defected element (location calculation using element length)